@extends('backend.layouts.app')

@section('title', 'Toronto Dashboard')
<link href="https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css">

<style>
    .dataTables_length,
    .dataTables_wrapper {
        font-size: 1.6rem;

        select,
        input {
            background-color: #f9f9f9;
            border: 1px solid #999;
            border-radius: 4px;
            height: 3rem;
            line-height: 2;
            font-size: 1.8rem;
            color: #333;
        }

        .dataTables_length,
        .dataTables_filter {
            margin-top: 30px;
            margin-right: 20px;
            margin-bottom: 10px;
            display: inline-flex;
        }
    }

    // paginate

    .paginate_button {
        min-width: 4rem;
        display: inline-block;
        text-align: center;
        padding: 1rem 1.6rem;
        margin-top: -1rem;
        border: 2px solid lightblue;

        &:not(.previous) {
            border-left: none;
        }

        &.previous {
            border-radius: 8px 0 0 8px;
            min-width: 7rem;
        }

        &.next {
            border-radius: 0 8px 8px 0;
            min-width: 7rem;
        }

        &:hover {
            cursor: pointer;
            background-color: #eee;
            text-decoration: none;
        }
    }
</style>

@section('dataTablJs')
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#example").DataTable();
        });
    </script>

@endsection
@section('content')


    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3 class="text-center">Order List<small></small></h3>
                </div>
            </div>

            <div class="row">

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <form method="get" action="">
                                <div class="row">
                                    <div class="col-md-3" hidden>
                                        <label>Search By Date :</label>
                                        <input type="date" hidden name="datepicker" class="data-selector form-control"
                                            required=""
                                            value="{{ isset($_GET['datepicker']) ? $_GET['datepicker'] : date('Y-m-d') }}">
                                        <input type="hidden" name="type" value="delivered" id="type">
                                    </div>
                                    <div class="col-md-3">

                                    </div>
                                    <div class="col-md-9 sm_custm">
                                        @if (can_access_route('newexport_MontrealDelivered.excel', $userPermissoins))
                                            <div class="excel-btn" style="float: right">
                                                <a href="{{ route('newexport_MontrealDelivered.excel') }}"
                                                    class="btn buttons-excel buttons-html5 btn-sm btn-primary excelstyleclass">
                                                    Export to Excel
                                                </a>
                                            </div>
                                        @endif
                                        <div class="excel-btn" style="float: right">
                                            <a href="#"
                                                class="btn buttons-reload buttons-html5 btn-sm btn-danger excelstyleclass">
                                                Reload
                                            </a>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </form>

                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">

                            <div class="container">
                                <div class="row">

                                    <table id="example" class="table table-striped table-bordered" cellspacing="0"
                                        width="100%">
                                        <thead>
                                            <tr>
                                                <th style="width: 5%" class="text-center ">ID</th>
                                                <th style="width: 30%" class="text-center ">Name</th>
                                                <th style="width: 30%" class="text-center ">Max Distance</th>
                                                <th style="width: 30%" class="text-center ">Pickup Price</th>
                                                <th style="width: 30%" class="text-center ">Distance Price</th>
                                                <th style="width: 30%" class="text-center ">Dropoff Price</th>
                                                <th style="width: 30%" class="text-center ">Distance Allowance</th>
                                                <th style="width: 30%" class="text-center ">Third Party Pickup Price</th>
                                                <th style="width: 30%" class="text-center ">Ordinal</th>
                                                <th style="width: 30%" class="text-center ">Capacity</th>
                                                <th style="width: 30%" class="text-center ">Min Visits</th>
                                                <th style="width: 10%" class="text-center ">Total </th>
                                                <th style="width: 10%" class="text-center ">Vehicle Id </th>
                                                <th style="width: 10%" class="text-center ">Order Status </th>
                                                <th style="width: 20%" class="text-center ">Created at</th>
                                                <th style="width: 5%" class="text-center">Actions</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th style="width: 5%" class="text-center ">ID</th>
                                                <th style="width: 30%" class="text-center ">Name</th>
                                                <th style="width: 30%" class="text-center ">Max Distance</th>
                                                <th style="width: 30%" class="text-center ">Pickup Price</th>
                                                <th style="width: 30%" class="text-center ">Distance Price</th>
                                                <th style="width: 30%" class="text-center ">Dropoff Price</th>
                                                <th style="width: 30%" class="text-center ">Distance Allowance</th>
                                                <th style="width: 30%" class="text-center ">Third Party Pickup Price</th>
                                                <th style="width: 30%" class="text-center ">Ordinal</th>
                                                <th style="width: 30%" class="text-center ">Capacity</th>
                                                <th style="width: 30%" class="text-center ">Min Visits</th>
                                                <th style="width: 10%" class="text-center ">Total </th>
                                                <th style="width: 10%" class="text-center ">Vehicle Id </th>
                                                <th style="width: 10%" class="text-center ">Order Status </th>
                                                <th style="width: 20%" class="text-center ">Created at</th>
                                                <th style="width: 5%" class="text-center">Actions</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            <?php $i = 1; ?>
                                            @foreach ($order_detail as $user_list)
                                                <tr>
                                                    <td style="width: 5%" class="text-center ">{{$i}}</td>
                                                    <td style="width: 5%" class="text-center ">{{$user_list->vehicle['name']}}</td>
                                                    <td style="width: 5%" class="text-center ">{{ $user_list->vehicle['max_distance']}}</td>
                                                    <td style="width: 5%" class="text-center ">{{ $user_list->vehicle['pickup_price']}}</td>
                                                    <td style="width: 5%" class="text-center ">{{ $user_list->vehicle['distance_price']}}</td>
                                                    <td style="width: 5%" class="text-center ">{{ $user_list->vehicle['dropoff_price']}}</td>
                                                    <td style="width: 5%" class="text-center ">{{ $user_list->vehicle['distance_allowance ']}}</td>
                                                    <td style="width: 5%" class="text-center ">{{ $user_list->vehicle['third_party_pickup_price']}}</td>
                                                    <td style="width: 5%" class="text-center ">{{ $user_list->vehicle['ordinal']}}</td>
                                                    <td style="width: 5%" class="text-center ">{{ $user_list->vehicle['capacity']}}</td>
                                                    <td style="width: 5%" class="text-center ">{{ $user_list->vehicle['min_visits']}}</td>
                                                    <td style="width: 5%" class="text-center ">{{ $user_list->total}}</td>
                                                    <td style="width: 5%" class="text-center ">{{ $user_list->vehicle_id}}</td>
                                                    <td style="width: 5%" class="text-center ">{{ isset($status_code[$user_list->status_id])==1?$status_code[$user_list->status_id]:'Not Available'  }}</td>
                                                    <td style="width: 5%" class="text-center ">{{ $user_list->created_at}}</td>
                                                    <td style="width: 5%" class=" text-center"><a
                                                            href="{{url('order/show/'. $user_list->id)}}" title="Edit"
                                                            class="btn btn-xs btn-info">
                                                            <i class="fa fa-eye"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php $i++; ?>
                                            @endforeach
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->

@endsection
