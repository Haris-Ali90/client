<a href="{{backend_url('label-order/'.$record->id)}}" target="_blank" title="Detail" class="btn btn-primary btn-xs smBtn">
    Print Label
</a>