<?php
namespace App\Http\Controllers\Backend;
use DB;
?>
<table class="table table-striped table-bordered" border="1">
                            <thead>
                            <tr>
                                <th>Store Name</th>
                                <th>Order Id</th>
                                <th>Walamrt Order Number</th>
                                <th>Joey Name</th>
                                <th>Status</th>
                                <th>Schedule Pickup</th>
                                <th>Compliant Pickup</th>
                                <th>Pickup ETA</th>
                                <th>Joey Arrival Time</th>
                                <th>Joey Departure Time</th>
                                <th>Compliant Dropoff</th>
                                <th>Dropoff ETA</th>
                                <th>Delivery Time</th>
                                <th>Location</th>
                                <!-- <th>Notes</th> -->
                                <th>Marked Codes</th>
                            </tr>
                            </thead><tbody>
                            <?php $allrec=0;
                    if(!empty($fullrecord)){
                    foreach($fullrecord as $record) { 

                        if(strtotime($record->departure_time)>strtotime($record->delivery_time)){
                            $delivery_time = "20".date('y-m-d H:i:s',strtotime($record->departure_time)+120);
                        }
                        else {
                            $delivery_time = $record->delivery_time;
                        }
                        $allrec++;  ?>
                        <tr>
                            <td><?php echo $record->store_name; ?></td>
                            <td <?php if(strtotime($record->compliant_dropoff)+300 < strtotime($delivery_time) ) echo "style='background:red'"; ?> >CR-<?php echo $record->sprint_id; ?></td>
                            <td><?php echo $record->walmart_order_num?></td>
                            <td><?php echo $record->joey_name?></td>
                            <td><?php echo $status[$record->status_id]; ?></td>
                            <td><?php echo $record->schedule_pickup; ?></td>
                            <td><?php echo $record->compliant_pickup; ?></td>
                            <td><?php echo $record->pickup_eta; ?></td>
                            <td><?php echo $record->arrival_time; ?></td>
                            <td><?php echo $record->departure_time; ?></td>
                            <td><?php echo $record->compliant_dropoff; ?></td>
                            <td><?php echo $record->dropoff_eta?></td>
                            <td><?php  echo $delivery_time; ?></td>
                            <td><?php echo $record->address; ?></td>
                            <!-- <td>
                            <?php 
                            // $notes = \Laravel\Database::query("select note from notes where object_id=".$record->sprint_id."");
                            // foreach ($notes as $note) {
                            //     echo $note->note.". ";
                            // } 
                            ?>
                            </td>  -->
                            <td><?php 
                            $codes = DB::select("select code from order_code join order_assigned_code on (order_assigned_code.code_id=order_code.id) where sprint_id=".$record->sprint_id."");
                            foreach ($codes as $code) {
                                echo $code->code.",";
                            } 
                            ?></td>
                        </tr>
                    <?php }} ?>    
                        </tbody>
                            </table>
                            
            <?php
                $start=1;
                $end=10;
                $total_pages=10;
                //$page=5;
                if($total_pages > 1) { ?>
                <ul class="pagination pagination-sm justify-content-center">
                    <!-- Link of the first page -->
                    <li class='page-item <?php ($page <= 1 ? print 'disabled' : '')?>'>
                      <button class='paginationbt btn btn-primary'  url-for='total-orders-summary' data-id='1'><<</button>
                    </li>
                    <!-- Link of the previous page -->
                    <li class='page-item <?php ($page <= 1 ? print 'disabled' : '')?>'>
                      <button class='paginationbt btn btn-primary'  url-for='total-orders-summary' data-id='<?php ($page>1 ? print($page-1) : print 1)?>'><</button>
                    </li>
                    <!-- Links of the pages with page number -->
                    <?php $active=""; for($i=$start; $i<=$end; $i++) { ?>

                        <li class='page-item <?php
                            if($i == $page){
                                $active='green';
                            }else{$active="";}?>'>
                          <button class='<?php echo 'paginationbt  btn btn-primary'.$active ?>'   url-for='total-orders-summary' data-id='<?php echo $i;?>'><?php echo $i;?></button>
                        </li>
                    <?php } ?>
                    <!-- Link of the next page -->
                    <li class='page-item <?php ($page >= $total_pages ? print 'disabled' : '')?>'>
                      <button class='paginationbt btn btn-primary'  url-for='total-orders-summary' data-id='<?php ($page < $total_pages ? print($page+1) : print $total_pages)?>'>></button>
                    </li>
                    <!-- Link of the last page -->
                    <li class='page-item <?php ($page >= $total_pages ? print 'disabled' : '')?>'>
                      <button class='paginationbt btn btn-primary' url-for='total-orders-summary' data-id='<?php echo $total_pages;?>'>>>
                      </button>
                    </li>
                </ul>
            <?php } ?>
          </div>
        </div>
    </div>
