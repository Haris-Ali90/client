<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AccountCard extends Model
{
    //

    protected $guarded = [];
}
