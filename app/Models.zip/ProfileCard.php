<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProfileCard extends Model {
    /**
     * Table name.
     *
     * @var array
     */

    // public $table = 'profile_cards';

    /**
     * The attributes that are guarded.
     *
     * @var array
     */
    protected $guarded = [];




}